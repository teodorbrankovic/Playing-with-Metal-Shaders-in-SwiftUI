//
//  BootCamp_PreparationApp.swift
//  BootCamp_Preparation
//
//  Created by Teodor Brankovic on 15.06.24.
//

import SwiftUI

@main
struct BootCamp_PreparationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
